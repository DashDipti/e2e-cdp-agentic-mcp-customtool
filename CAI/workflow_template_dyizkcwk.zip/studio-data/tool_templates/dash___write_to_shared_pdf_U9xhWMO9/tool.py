"""
Writes markdown content to a beautifully styled PDF file.

Files are created in the artifact file directory (/workspace) using relative paths.
The sandbox automatically sets the working directory to /workspace, so relative paths
like "report.pdf" will resolve to /workspace/report.pdf automatically.
"""

from pydantic import BaseModel, Field
from typing import Any
import json
import argparse
from pathlib import Path
from markdown_it import MarkdownIt
from mdit_py_plugins.front_matter import front_matter_plugin
from mdit_py_plugins.footnote import footnote_plugin
from weasyprint import HTML, CSS


# ── Embedded design system ────────────────────────────────────────────────────

STYLES = """
/* ── Google Fonts ─────────────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&family=Merriweather:ital,wght@0,400;0,700;1,400&display=swap');

/* ── Page layout ──────────────────────────────────────────────────────────── */
@page {
    size: A4;
    margin: 22mm 20mm 28mm 20mm;

    @bottom-center {
        content: counter(page);
        font-family: 'Inter', sans-serif;
        font-size: 9pt;
        color: #9ca3af;
        padding-top: 8mm;
    }
    @bottom-right {
        content: string(doc-title);
        font-family: 'Inter', sans-serif;
        font-size: 8pt;
        color: #d1d5db;
        padding-top: 8mm;
        white-space: nowrap;
        overflow: hidden;
        max-width: 80mm;
    }
}

/* ── Base ─────────────────────────────────────────────────────────────────── */
:root {
    --brand:        #5b6af0;   /* indigo accent */
    --brand-light:  #eef0fd;
    --text-primary: #111827;
    --text-body:    #374151;
    --text-muted:   #6b7280;
    --text-faint:   #9ca3af;
    --border:       #e5e7eb;
    --border-strong:#d1d5db;
    --surface:      #f9fafb;
    --surface-2:    #f3f4f6;
    --code-bg:      #1e1e2e;   /* dark code surface */
    --code-text:    #cdd6f4;
    --radius:       6px;
    --radius-lg:    10px;
}

html {
    font-size: 10.5pt;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}

body {
    font-family: 'Inter', 'Segoe UI', Helvetica, Arial, sans-serif;
    color: var(--text-body);
    line-height: 1.75;
    background: #ffffff;
    margin: 0;
    padding: 0;
}

/* ── Headings ─────────────────────────────────────────────────────────────── */
h1, h2, h3, h4, h5, h6 {
    font-family: 'Inter', sans-serif;
    font-weight: 700;
    color: var(--text-primary);
    margin-top: 1.6em;
    margin-bottom: 0.4em;
    line-height: 1.3;
    letter-spacing: -0.01em;
    page-break-after: avoid;
}

h1 {
    string-set: doc-title content();
    font-size: 2em;
    font-weight: 800;
    color: var(--text-primary);
    border-bottom: 3px solid var(--brand);
    padding-bottom: 0.3em;
    margin-top: 0;
    letter-spacing: -0.03em;
}

h2 {
    font-size: 1.45em;
    border-bottom: 1.5px solid var(--border);
    padding-bottom: 0.25em;
    color: #1f2937;
}

h3 {
    font-size: 1.15em;
    color: #374151;
}

h4 {
    font-size: 1em;
    font-weight: 600;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    font-size: 0.8em;
}

h5, h6 {
    font-size: 0.9em;
    font-weight: 600;
    color: var(--text-muted);
}

/* ── Paragraphs ───────────────────────────────────────────────────────────── */
p {
    margin: 0 0 1em 0;
    color: var(--text-body);
    orphans: 3;
    widows: 3;
}

/* ── Links ────────────────────────────────────────────────────────────────── */
a {
    color: var(--brand);
    text-decoration: none;
    border-bottom: 1px solid transparent;
}
a:hover {
    border-bottom-color: var(--brand);
}

/* ── Inline code ──────────────────────────────────────────────────────────── */
code {
    font-family: 'JetBrains Mono', 'Fira Code', 'Courier New', monospace;
    font-size: 0.83em;
    background: var(--surface-2);
    color: #c026d3;
    padding: 0.15em 0.45em;
    border-radius: 4px;
    border: 1px solid var(--border);
}

/* ── Code blocks ──────────────────────────────────────────────────────────── */
pre {
    background: var(--code-bg);
    border-radius: var(--radius-lg);
    padding: 1.1em 1.3em;
    overflow-x: auto;
    margin: 1.2em 0;
    box-shadow: 0 2px 8px rgba(0,0,0,0.18);
    page-break-inside: avoid;
    border-left: 4px solid var(--brand);
    position: relative;
}

pre code {
    font-family: 'JetBrains Mono', 'Fira Code', 'Courier New', monospace;
    font-size: 0.82em;
    background: transparent;
    color: var(--code-text);
    padding: 0;
    border: none;
    border-radius: 0;
    line-height: 1.6;
    white-space: pre;
    word-break: normal;
}

/* Pygments token colours (Catppuccin-inspired palette) */
pre .k  { color: #cba6f7; }   /* keyword */
pre .kd { color: #cba6f7; }
pre .kn { color: #cba6f7; }
pre .kp { color: #cba6f7; }
pre .kr { color: #cba6f7; }
pre .kt { color: #89dceb; }   /* keyword type */
pre .s  { color: #a6e3a1; }   /* string */
pre .s1 { color: #a6e3a1; }
pre .s2 { color: #a6e3a1; }
pre .sb { color: #a6e3a1; }
pre .sc { color: #a6e3a1; }
pre .sd { color: #a6e3a1; }
pre .se { color: #fab387; }   /* escape */
pre .si { color: #fab387; }
pre .sx { color: #a6e3a1; }
pre .sr { color: #89dceb; }
pre .ss { color: #89dceb; }
pre .mi { color: #fab387; }   /* number */
pre .mf { color: #fab387; }
pre .mh { color: #fab387; }
pre .mo { color: #fab387; }
pre .o  { color: #89dceb; }   /* operator */
pre .ow { color: #cba6f7; }
pre .c  { color: #585b70; font-style: italic; }  /* comment */
pre .cm { color: #585b70; font-style: italic; }
pre .c1 { color: #585b70; font-style: italic; }
pre .cs { color: #585b70; font-style: italic; }
pre .cp { color: #f38ba8; }
pre .nb { color: #89dceb; }   /* builtin */
pre .nc { color: #f9e2af; }   /* class */
pre .nf { color: #89b4fa; }   /* function */
pre .nn { color: #f9e2af; }
pre .nd { color: #cba6f7; }
pre .ni { color: #cdd6f4; }
pre .ne { color: #f38ba8; }
pre .nv { color: #cdd6f4; }
pre .na { color: #89b4fa; }
pre .nt { color: #cba6f7; }
pre .nx { color: #cdd6f4; }
pre .p  { color: #cdd6f4; }
pre .err{ color: #f38ba8; }

/* ── Blockquotes ──────────────────────────────────────────────────────────── */
blockquote {
    margin: 1.2em 0;
    padding: 0.9em 1.2em;
    background: var(--brand-light);
    border-left: 4px solid var(--brand);
    border-radius: 0 var(--radius) var(--radius) 0;
    color: #3730a3;
    font-style: italic;
    page-break-inside: avoid;
}

blockquote p {
    margin: 0;
    color: inherit;
}

blockquote > blockquote {
    background: #dbeafe;
    border-left-color: #3b82f6;
    color: #1e40af;
    margin-top: 0.6em;
}

/* ── Tables ───────────────────────────────────────────────────────────────── */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 1.4em 0;
    font-size: 0.9em;
    page-break-inside: avoid;
    border-radius: var(--radius-lg);
    overflow: hidden;
    box-shadow: 0 1px 4px rgba(0,0,0,0.07);
}

thead {
    background: var(--brand);
    color: #ffffff;
}

thead th {
    padding: 0.65em 1em;
    text-align: left;
    font-weight: 600;
    font-size: 0.85em;
    letter-spacing: 0.03em;
    text-transform: uppercase;
    border: none;
}

tbody tr:nth-child(even) {
    background: var(--surface);
}

tbody tr:nth-child(odd) {
    background: #ffffff;
}

tbody tr:hover {
    background: var(--brand-light);
}

tbody td {
    padding: 0.6em 1em;
    border-bottom: 1px solid var(--border);
    vertical-align: top;
    color: var(--text-body);
}

tbody tr:last-child td {
    border-bottom: none;
}

/* ── Lists ────────────────────────────────────────────────────────────────── */
ul, ol {
    margin: 0.6em 0 1em 0;
    padding-left: 1.6em;
}

li {
    margin-bottom: 0.3em;
    line-height: 1.65;
}

ul li::marker {
    color: var(--brand);
}

ol li::marker {
    color: var(--brand);
    font-weight: 600;
}

/* Nested lists */
li > ul, li > ol {
    margin-top: 0.3em;
    margin-bottom: 0.3em;
}

/* Task lists */
ul.task-list {
    list-style: none;
    padding-left: 0.3em;
}
ul.task-list li::before { content: none; }
input[type="checkbox"] {
    margin-right: 0.5em;
    accent-color: var(--brand);
}

/* ── Horizontal rules ─────────────────────────────────────────────────────── */
hr {
    border: none;
    border-top: 2px solid var(--border);
    margin: 2em 0;
}

/* ── Images ───────────────────────────────────────────────────────────────── */
img {
    max-width: 100%;
    height: auto;
    border-radius: var(--radius);
    display: block;
    margin: 1em auto;
    box-shadow: 0 2px 10px rgba(0,0,0,0.10);
}

/* ── Definition lists ─────────────────────────────────────────────────────── */
dl {
    margin: 1em 0;
}
dt {
    font-weight: 600;
    color: var(--text-primary);
    margin-top: 0.7em;
}
dd {
    margin-left: 1.5em;
    color: var(--text-body);
}

/* ── Footnotes ────────────────────────────────────────────────────────────── */
.footnotes {
    border-top: 1px solid var(--border);
    margin-top: 2.5em;
    padding-top: 1em;
    font-size: 0.85em;
    color: var(--text-muted);
}

.footnotes ol {
    padding-left: 1.2em;
}

/* ── Callout / admonition blocks (GitHub-style alerts) ───────────────────── */
.callout {
    display: flex;
    gap: 0.75em;
    padding: 0.9em 1.1em;
    border-radius: var(--radius);
    margin: 1.2em 0;
    page-break-inside: avoid;
}

/* ── Marks / highlights ───────────────────────────────────────────────────── */
mark {
    background: #fef9c3;
    color: #713f12;
    padding: 0 0.25em;
    border-radius: 3px;
}

/* ── Strong / em ──────────────────────────────────────────────────────────── */
strong { color: var(--text-primary); font-weight: 700; }
em     { color: #4b5563; }

/* ── Print utilities ──────────────────────────────────────────────────────── */
.page-break { page-break-after: always; }
"""


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Document</title>
</head>
<body>
{body}
</body>
</html>"""


# ── Pydantic models ────────────────────────────────────────────────────────────

class UserParameters(BaseModel):
    pass


class ToolParameters(BaseModel):
    output_file: str = Field(
        description="The file name of the PDF to write. Example: 'report.pdf'"
    )
    markdown_content: str = Field(
        description="The markdown content to render into the PDF."
    )


# ── Core logic ─────────────────────────────────────────────────────────────────

def build_html(markdown_content: str) -> str:
    """Convert markdown to a fully self-contained HTML string."""
    md = (
        MarkdownIt("commonmark", {"highlight": _highlight_code})
        .enable("table")
        .enable("strikethrough")
        .use(front_matter_plugin)
        .use(footnote_plugin)
    )
    body_html = md.render(markdown_content)
    return HTML_TEMPLATE.format(body=body_html)


def _highlight_code(code: str, lang: str, _attrs: str) -> str:
    """Pygments-based syntax highlighting that injects span classes."""
    try:
        from pygments import highlight
        from pygments.lexers import get_lexer_by_name, TextLexer
        from pygments.formatters import HtmlFormatter

        try:
            lexer = get_lexer_by_name(lang) if lang else TextLexer()
        except Exception:
            lexer = TextLexer()

        formatter = HtmlFormatter(nowrap=True)
        highlighted = highlight(code, lexer, formatter)
        return f'<pre><code class="language-{lang}">{highlighted}</code></pre>'
    except ImportError:
        # Pygments not installed — plain fallback
        import html as _html
        return f'<pre><code class="language-{lang}">{_html.escape(code)}</code></pre>'


def run_tool(config: UserParameters, args: ToolParameters) -> Any:
    output_path = Path(args.output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    full_html = build_html(args.markdown_content)

    HTML(
        string=full_html,
        base_url=str(output_path.parent.resolve()),
    ).write_pdf(
        output_path,
        stylesheets=[CSS(string=STYLES)],
    )

    return {"path": args.output_file}


# ── Entry point ────────────────────────────────────────────────────────────────

OUTPUT_KEY = "tool_output"

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--user-params", required=True)
    parser.add_argument("--tool-params", required=True)
    cli_args = parser.parse_args()

    user_dict = json.loads(cli_args.user_params)
    tool_dict = json.loads(cli_args.tool_params)

    config = UserParameters(**user_dict)
    params = ToolParameters(**tool_dict)

    output = run_tool(config, params)
    print(OUTPUT_KEY, output)